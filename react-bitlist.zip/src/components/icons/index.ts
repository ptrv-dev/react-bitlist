import MailIcon from './MailIcon';
import SearchIcon from './SearchIcon';

export { MailIcon, SearchIcon };
